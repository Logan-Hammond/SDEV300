# Author:		Logan Hammond; lhammond12@student.umuc.edu
# Source File:  WebPage.py
# Description:  Creates a simple webpage using Flask on an AWS Cloud9 instance. 
# IDE:			AWS Cloud9

from flask import Flask, render_template
from datetime import datetime

app = Flask(__name__)
cur_date = datetime.now().date()
cur_time = datetime.now().time()

@app.route("/hello")
def hello():
    return render_template("index.html", date=cur_date, time=cur_time)
    
app.run(host="0.0.0.0", port=8080)