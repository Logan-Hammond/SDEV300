# Author:		Logan Hammond; lhammond12@student.umuc.edu
# Source File:  SetTests.py
# Description:  Progam that allows users to view the union, intersection, and
#               difference of the squares and cubes of each integer (1, 100). 
# IDE:			AWS Cloud9

# import math

class SetTests:
    int_set = set()
    square_set = set()
    cube_set = set()
    
    def __init__(self):
        self.genSets()
        pass
    
    def genSets(self):
        for i in range(1, 101):
            self.int_set.add(i)
            self.square_set.add(i**2)
            self.cube_set.add(i**3)
            pass
        pass

    # End of class
    pass

def main():
    set_tests = SetTests()
    set_tests.genSets()
    
    # Display menu. 
    while True:
        print("\n\tSelect from the following menu...")
        print("\t\t1. Display square and cube for ints (1,100).")
        print("\t\t2. Search for integer square and cube.")
        print("\t\t3. Display the union of square and cube sets.")
        print("\t\t4. Dispay the intersection of square and cube sets.")
        print("\t\t5. Dispay the difference of square and cube sets.")
        print("\t\t6. Exit the application.")
        
        # Get input from user and display it. 
        choice_int = int(input())
        print("\n\t\tYou selected {}".format(choice_int))
        
        # Sentinel check. 
        if choice_int == 6: 
            print("Thanks for using this application!")
            break
            
        # "Switch" logic. 
        if choice_int == 1:
            for i in set_tests.int_set:
                print("{}: {}, {}".format(i, i**2, i**3))
        elif choice_int == 2:
            print("\n\t\tEnter search integer.")
            search_int = int(input())
            if(search_int in set_tests.int_set):
                print("\t\t{}: {}, {}".format(search_int, search_int**2, 
                search_int**3))
            else:
                print("\t\tInvalid input. Please try again.")
        elif choice_int == 3:
            print(sorted(set_tests.square_set | set_tests.cube_set))
        elif choice_int == 4:
            print(sorted(set_tests.square_set & set_tests.cube_set))
        elif choice_int == 5: 
            print(sorted(set_tests.square_set - set_tests.cube_set))
        else:
            print("Invalid input. Please try again.")
    
    # End of main. 
    pass

if __name__ == "__main__":
    main()
    pass
