# Author:		Logan Hammond; lhammond12@student.umuc.edu
# Source File:  WebPage.py
# Description:  Creates a simple webpage using Flask on an AWS Cloud9 instance. 
# IDE:			AWS Cloud9

from flask import Flask, render_template, request, redirect
from datetime import datetime

app = Flask(__name__, static_url_path="/static")
cur_date = datetime.now().date()
cur_time = datetime.now().time()

@app.route("/hello", methods=["GET", "POST"])
def hello():
    return render_template("index.html", date=cur_date, time=cur_time)

@app.route("/signup", methods=["POST"])
def signup():
    # Get form data
    title = request.form["title"]
    name = request.form["name"]
    email = request.form["email"]
    comment = request.form["comment"]
    
    # Create or update output file. 
    f = open("Lab7/output.txt", "a+")
    f.write("{}\n{} {}\n{}\n{}\n\n".format(datetime.now(), title, name, email
                                                   , comment))
    
    return redirect("/hello")
    
app.run(host="0.0.0.0", port=8080)