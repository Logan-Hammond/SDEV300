# Author:		Logan Hammond; lhammond12@student.umuc.edu
# Source File:  WebPage.py
# Description:  Program that allows user to load one of two CSV files and then 
#               perform histogram analysis and plots for select variables on 
#               the datasets.
# IDE:			AWS Cloud9

from matplotlib import pyplot as plt
import numpy as np
import pandas as pd

class CSVAnalyzer():
    df = None
    
    def analyze(self, col_name):
        
        # Determine what file to load into dataframe. 
        if col_name in ["Pop Apr 1", "Pop Jul 1", "Change Pop"]:
            df = pd.read_csv("Lab5/PopChange.csv")
        elif col_name in ["AGE", "BEDRMS", "BUILT", "ROOMS", "UTILITY"]: 
            df = pd.read_csv("Lab5/Housing.csv")
        else: 
            print("Error. Cannot find that column in either file.")
            exit()
        
        # Create dictionary of relevant data from given column. 
        analysis_dic = {
            "Count": len(df.index),
            "Mean": int(df[col_name].mean()),
            "S.Dev.": int(df[col_name].std()),
            "Min": df[col_name].min(),
            "Max": df[col_name].max()
        }
        
        # TODO: Create histogram of relevant data for given column. 
        
        return analysis_dic
        
def main():
    popchange_fp = "Lab5/PopChange.csv"
    housing_fp = "Lab5/Housing.csv"
    csva = CSVAnalyzer()
    
    print("\t\tWelcome to the Python Data Analysis App")
    while True:
        print("\nSelect the file you want to analyze...")
        print("\t1. Population Data.")
        print("\t2. Housing Data.")
        print("\t3. Exit the application.")
        
        # Get input from user and display it. 
        try:
            choice_int = int(input())
            print("\nYou selected {}.".format(choice_int))
        except ValueError: 
            print("\nInvalid input. Please try again.")
            continue
        
        if choice_int == 3:
            print("\nThanks for using this application!")
            break
        if choice_int == 1:
            data_dict = {}
            print("\nYou selected Population Data. Please select column.")
            while True:
                print("\n\t1. Pop Apr 1")
                print("\t2. Pop Jul 1")
                print("\t3. Change Pop")
                print("\t4. Exit column.")
                try:
                    new_choice_int = int(input())
                    print("\nYou selected {}.".format(new_choice_int))
                except ValueError: 
                    print("\nInvalid input. Please try again.")
                    continue
                if new_choice_int == 4:
                    break
                if new_choice_int == 1:
                     data_dict = csva.analyze("Pop Apr 1")
                elif new_choice_int == 2:
                    data_dict = csva.analyze("Pop Jul 1")
                elif new_choice_int == 3:
                    data_dict = csva.analyze("Change Pop")
                    
                for key, value in data_dict.items():
                    print("\t{}\t= {}".format(key, data_dict[key]))
                
        elif choice_int ==2: 
            data_dict = {}
            print("\nYou selected Housing Data. Please select column.")
            while True:
                print("\n\t1. AGE")
                print("\t2. BEDRMS")
                print("\t3. BUILT")
                print("\t4. ROOMS")
                print("\t5. UTILITY")
                print("\t6. Exit column.")
                try:
                    new_choice_int = int(input())
                    print("\nYou selected {}.".format(new_choice_int))
                except ValueError: 
                    print("\nInvalid input. Please try again.")
                    continue
                if new_choice_int == 6:
                    break
                if new_choice_int == 1:
                     data_dict = csva.analyze("AGE")
                elif new_choice_int == 2:
                    data_dict = csva.analyze("BEDRMS")
                elif new_choice_int == 3:
                    data_dict = csva.analyze("BUILT")
                elif new_choice_int == 4:
                     data_dict = csva.analyze("ROOMS")
                elif new_choice_int == 5:
                    data_dict = csva.analyze("UTILITY")
                for key, value in data_dict.items():
                    print("\t{}\t= {}".format(key, data_dict[key]))
        else: 
            print("Invalid input. Please try again.")
            
if __name__ == "__main__":
    main()
